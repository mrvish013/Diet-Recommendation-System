// AdminComponent.js
import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const AdminComponent = ({ children }) => {
    const { user } = useContext(AuthContext);

    return user && user.role === 'admin' ? children : <Navigate to='/login' />;
};

export default AdminComponent;
