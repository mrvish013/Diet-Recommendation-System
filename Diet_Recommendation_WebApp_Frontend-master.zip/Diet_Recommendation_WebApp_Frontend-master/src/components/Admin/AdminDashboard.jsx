import React from 'react'

export default function AdminDashboard() {
    return (
        <div>AdminDashboard</div>
    )
}
